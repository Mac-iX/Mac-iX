import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AboutUs() {
  return (
    <section id="about" className="py-20 bg-background/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">About Quality Creative Consulting</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're on a mission to democratize AI knowledge and empower organizations to leverage the full potential of
            generative technologies.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold mb-4 text-foreground">Our Mission</h3>
            <p className="text-muted-foreground mb-6">
              At Quality Creative Consulting, we believe that AI literacy is becoming as essential as digital literacy
              was a decade ago. Our mission is to bridge the knowledge gap and equip teams with the practical skills
              needed to thrive in an AI-augmented future.
            </p>
            <p className="text-muted-foreground">
              We focus on practical, hands-on training that delivers immediate value, helping organizations build
              internal capabilities rather than dependencies on external consultants.
            </p>
          </div>
          <div className="relative h-[300px] rounded-lg overflow-hidden shadow-lg">
            {/* Placeholder for team photo */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <span className="text-primary/50 text-lg">{/* TeamPhoto */}Team Photo Placeholder</span>
            </div>
          </div>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-bold mb-8 text-center text-foreground">Leadership</h3>
          <div className="max-w-2xl mx-auto">
            <Card className="border-none shadow-lg">
              <CardHeader className="flex flex-col md:flex-row items-center gap-6">
                <Avatar className="h-24 w-24">
                  <AvatarImage src="/images/mac-carter.png" alt="Mac Carter" />
                  <AvatarFallback>MC</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-2xl">Mac Carter</CardTitle>
                  <CardDescription className="text-lg">Founder & Lead Consultant</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Mac Carter is a recognized expert in Generative AI and Prompt Engineering with over a decade of
                  experience in AI implementation across various industries. Before founding Quality Creative
                  Consulting, Mac led AI transformation initiatives at several Fortune 500 companies and has been a
                  frequent speaker at technology conferences worldwide.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold mb-8 text-center text-foreground">Our Team</h3>
          <p className="text-center text-muted-foreground max-w-3xl mx-auto mb-8">
            Quality Creative Consulting is home to a diverse team of 25-50 AI specialists, prompt engineers, industry
            experts, and instructional designers who bring a wealth of experience to every client engagement.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="text-center">
                <CardHeader>
                  <Avatar className="h-20 w-20 mx-auto">
                    <AvatarImage src={`/placeholder.svg?height=80&width=80`} alt={`Team Member ${i}`} />
                    <AvatarFallback>TM</AvatarFallback>
                  </Avatar>
                  <CardTitle className="mt-4">Team Member</CardTitle>
                  <CardDescription>AI Specialist</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

