import { Brain, Code } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function Services() {
  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive training and consulting services designed to elevate your team's AI capabilities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <Card className="shadow-lg border-t-4 border-t-primary">
            <CardHeader>
              <div className="mb-4">
                <Brain className="h-12 w-12 text-primary" />
              </div>
              <CardTitle className="text-2xl">Gen AI Training</CardTitle>
              <CardDescription className="text-base">
                Comprehensive training on generative AI fundamentals, applications, and implementation strategies.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">What You'll Learn:</h4>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Understanding different types of generative AI models</li>
                  <li>Practical applications across various business functions</li>
                  <li>Implementation strategies and best practices</li>
                  <li>Ethical considerations and responsible AI usage</li>
                  <li>Measuring ROI and performance metrics</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Format Options:</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">Workshops</Badge>
                  <Badge variant="outline">Executive Briefings</Badge>
                  <Badge variant="outline">Multi-Day Training</Badge>
                  <Badge variant="outline">Ongoing Consulting</Badge>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Learn More</Button>
            </CardFooter>
          </Card>

          <Card className="shadow-lg border-t-4 border-t-primary">
            <CardHeader>
              <div className="mb-4">
                <Code className="h-12 w-12 text-primary" />
              </div>
              <CardTitle className="text-2xl">Prompt Engineering Training</CardTitle>
              <CardDescription className="text-base">
                Master the art and science of crafting effective prompts to get the most out of AI systems.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">What You'll Learn:</h4>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Prompt engineering fundamentals and best practices</li>
                  <li>Advanced techniques for complex tasks</li>
                  <li>Domain-specific prompt optimization</li>
                  <li>Prompt libraries and management systems</li>
                  <li>Measuring and improving prompt effectiveness</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Format Options:</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">Hands-on Workshops</Badge>
                  <Badge variant="outline">Technical Deep Dives</Badge>
                  <Badge variant="outline">Custom Prompt Development</Badge>
                  <Badge variant="outline">Team Training</Badge>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Learn More</Button>
            </CardFooter>
          </Card>
        </div>

        <div className="bg-background/50 border border-border rounded-xl p-8 mb-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-4">Consulting Retainer Options</h3>
            <p className="text-muted-foreground">
              Our flexible retainer options allow you to access ongoing support and expertise as your AI journey
              evolves.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Starter</CardTitle>
                <div className="text-3xl font-bold">$1,500</div>
                <CardDescription>per month</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>10 hours of consulting</li>
                  <li>Monthly strategy session</li>
                  <li>Email support</li>
                  <li>Access to basic resources</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Get Started
                </Button>
              </CardFooter>
            </Card>

            <Card className="border-primary shadow-lg">
              <CardHeader>
                <CardTitle>Professional</CardTitle>
                <div className="text-3xl font-bold">$4,500</div>
                <CardDescription>per month</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>30 hours of consulting</li>
                  <li>Bi-weekly strategy sessions</li>
                  <li>Priority email and phone support</li>
                  <li>Custom prompt development</li>
                  <li>Quarterly training workshops</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Recommended</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Enterprise</CardTitle>
                <div className="text-3xl font-bold">$9,500</div>
                <CardDescription>per month</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Unlimited consulting hours</li>
                  <li>Weekly strategy sessions</li>
                  <li>24/7 priority support</li>
                  <li>Dedicated consultant</li>
                  <li>Custom training programs</li>
                  <li>AI implementation assistance</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Contact Sales
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">Custom Solutions</h3>
          <p className="text-muted-foreground max-w-3xl mx-auto mb-8">
            Need something more tailored to your specific needs? We offer custom training and consulting packages
            designed specifically for your organization's unique challenges and goals.
          </p>
          <Button size="lg">Request Custom Quote</Button>
        </div>
      </div>
    </section>
  )
}

