"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-sm border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <span className="text-xl font-bold text-primary">Quality Creative Consulting</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/#overview" className="text-muted-foreground hover:text-primary transition-colors">
            Overview
          </Link>
          <Link href="/#about" className="text-muted-foreground hover:text-primary transition-colors">
            About Us
          </Link>
          <Link href="/#services" className="text-muted-foreground hover:text-primary transition-colors">
            Services
          </Link>
          <Link href="/#testimonials" className="text-muted-foreground hover:text-primary transition-colors">
            Testimonials
          </Link>
          <Link href="/#contact" className="text-muted-foreground hover:text-primary transition-colors">
            Contact
          </Link>
          <Button size="sm">Schedule a Consultation</Button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={toggleMenu}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <Link
              href="/#overview"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={toggleMenu}
            >
              Overview
            </Link>
            <Link
              href="/#about"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={toggleMenu}
            >
              About Us
            </Link>
            <Link
              href="/#services"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={toggleMenu}
            >
              Services
            </Link>
            <Link
              href="/#testimonials"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={toggleMenu}
            >
              Testimonials
            </Link>
            <Link
              href="/#contact"
              className="text-muted-foreground hover:text-primary transition-colors py-2"
              onClick={toggleMenu}
            >
              Contact
            </Link>
            <Button className="w-full">Schedule a Consultation</Button>
          </div>
        </div>
      )}
    </nav>
  )
}

