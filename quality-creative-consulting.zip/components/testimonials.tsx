import { Quote } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Testimonials() {
  const testimonials = [
    {
      quote:
        "Quality Creative Consulting transformed our approach to AI. Their prompt engineering training has become an essential skill for our product team, resulting in a 40% increase in productivity.",
      name: "Sarah Johnson",
      title: "CTO, TechInnovate",
      avatar: "/placeholder.svg?height=48&width=48",
    },
    {
      quote:
        "Mac and his team provided exactly what our executives needed - clear, practical guidance on how to leverage generative AI for strategic advantage. Highly recommended.",
      name: "Michael Chen",
      title: "VP of Innovation, Global Enterprises",
      avatar: "/placeholder.svg?height=48&width=48",
    },
    {
      quote:
        "The ROI on our training investment was evident within weeks. Our marketing team is now creating AI-assisted content that has increased our engagement metrics by 35%.",
      name: "Jessica Williams",
      title: "Marketing Director, Brand Leaders Inc.",
      avatar: "/placeholder.svg?height=48&width=48",
    },
    {
      quote:
        "What sets Quality Creative Consulting apart is their ability to make complex AI concepts accessible to everyone, from technical teams to senior leadership.",
      name: "David Rodriguez",
      title: "Head of Product, Future Solutions",
      avatar: "/placeholder.svg?height=48&width=48",
    },
  ]

  // Placeholder variable for ClientTestimonials
  const ClientTestimonials = "More Case Studies Coming Soon"

  return (
    <section id="testimonials" className="py-20 bg-background/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Client Success Stories</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Hear from organizations that have transformed their capabilities through our training and consulting
            services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="shadow-md">
              <CardContent className="pt-6">
                <Quote className="h-8 w-8 text-primary/40 mb-4" />
                <p className="text-muted-foreground italic mb-6">{testimonial.quote}</p>
              </CardContent>
              <CardFooter className="border-t pt-6">
                <div className="flex items-center">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-muted-foreground text-sm">{testimonial.title}</p>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-6">Want to see more detailed case studies of our work?</p>
          <div className="inline-block relative h-[200px] w-full max-w-2xl rounded-lg overflow-hidden shadow-lg">
            {/* Placeholder for case studies */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <span className="text-primary/50 text-lg">{ClientTestimonials}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

