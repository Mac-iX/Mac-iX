import { Lightbulb, Users, TrendingUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Overview() {
  return (
    <section id="overview" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Transforming Teams Through AI Expertise
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Quality Creative Consulting provides specialized training and consulting services to help your organization
            harness the power of Generative AI and Prompt Engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <Lightbulb className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Expert-Led Training</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Our training programs are designed and delivered by industry experts with extensive experience in AI
                implementation and prompt engineering.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Users className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Tailored for Teams</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                We customize our training to match your team's specific needs, ensuring relevant and immediately
                applicable knowledge transfer.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <TrendingUp className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Measurable Results</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Our clients see tangible improvements in productivity, innovation, and competitive advantage through our
                structured approach.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

