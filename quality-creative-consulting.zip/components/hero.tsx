import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-r from-primary/20 to-primary/10 py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-foreground">
              Unlock the Future with Gen AI & Prompt Engineering
            </h1>
            <p className="text-xl text-muted-foreground">
              Empower your team with cutting-edge AI skills that drive innovation and efficiency in today's competitive
              landscape.
            </p>
            <div className="pt-4">
              <Button size="lg" className="mr-4">
                Schedule a Consultation
              </Button>
              <Button variant="outline" size="lg">
                Learn More
              </Button>
            </div>
          </div>
          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-xl">
            {/* Placeholder for hero image */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <span className="text-primary/50 text-lg">Hero Image Placeholder</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

