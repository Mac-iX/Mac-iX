import Hero from "@/components/hero"
import Overview from "@/components/overview"
import AboutUs from "@/components/about-us"
import Services from "@/components/services"
import Testimonials from "@/components/testimonials"
import Contact from "@/components/contact"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Overview />
      <AboutUs />
      <Services />
      <Testimonials />
      <Contact />
    </main>
  )
}

